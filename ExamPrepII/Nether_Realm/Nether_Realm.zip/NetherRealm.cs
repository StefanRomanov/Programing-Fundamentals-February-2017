﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Nether_Realm
{
    class NetherRealm
    {
        public static void Main()
        {
            var numbers = new Regex("(-|\\+)*\\d+(\\.\\d+)*");
            var letters = new Regex("[A-Za-z]");
            var dividers = new Regex("\\/|\\*");

            var demons = Console.ReadLine()
                .Split(new[] { ',', ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries)
                .ToArray();
            var listOfDemons = new List<Demon>();

            for (int i = 0; i < demons.Length; i++)
            {
                var demon = new Demon();
                demon.Name = demons[i];

                var lettersInName = letters.Matches(demons[i]);
                var numbersInName = numbers.Matches(demons[i]);
                var symbols = dividers.Matches(demons[i]);
                var numberSum = 0.0;
                var letterSum = 0;
                var damage = 0.0;

                foreach (Match letter in lettersInName)
                {
                    letterSum += (int)(char.Parse(letter.ToString()));
                }
                foreach (var number in numbersInName)
                {
                    numberSum += double.Parse(number.ToString());
                }
                foreach (var symbol in symbols)
                {
                    var whatever = symbol.ToString();
                    if (whatever == "/")
                    {
                        damage += numberSum / 2;
                    }
                    else
                    {
                        damage += numberSum * 2;
                    }
                }

                demon.Damage = damage;
                demon.Health = letterSum;
                listOfDemons.Add(demon);
            }

            foreach (var demon in listOfDemons)
            {
                Console.WriteLine($"{demon.Name} - {demon.Health} health, {demon.Damage:f2} damage");
            }
        }
    }
}
