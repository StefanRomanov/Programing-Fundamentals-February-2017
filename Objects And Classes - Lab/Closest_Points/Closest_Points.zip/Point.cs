﻿using System;

namespace Closest_Points
{
    public class Point
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}
