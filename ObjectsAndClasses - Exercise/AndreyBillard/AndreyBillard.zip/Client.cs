﻿using System;
using System.Collections.Generic;

namespace Andrey_Billard
{
    public class Client
    {
        public string Name { get; set; }
        public Dictionary<string, int> ShopList { get; set; }
        public decimal Bill { get; set; }
    }
}
