﻿using System;

namespace Circle_Intersection
{
    class Circle
    {
        public Point center { get; set; }
        public double radius { get; set; }
    }
}
