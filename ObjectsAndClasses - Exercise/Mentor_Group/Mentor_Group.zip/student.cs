﻿using System;
using System.Collections.Generic;

namespace Mentor_Group
{
    public class Student
    {
        public string Name { get; set; }
        public List<DateTime> Dates { get; set; }
        public List<string> Comments { get; set; }
    }
}
