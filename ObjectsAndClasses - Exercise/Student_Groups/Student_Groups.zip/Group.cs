﻿using System.Collections.Generic;

namespace Student_Groups
{
    public class Group
    {
        public List<Student> Students { get; set; }
        public Town Town { get; set; }
    }
}
