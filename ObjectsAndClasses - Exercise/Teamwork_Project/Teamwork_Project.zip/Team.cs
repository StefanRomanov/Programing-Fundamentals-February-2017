﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Teamwork_Project
{
    class Team
    {
        public string Name { get; set; }
        public string Creator { get; set; }
        public List<string> Members { get; set; }
    }
}
